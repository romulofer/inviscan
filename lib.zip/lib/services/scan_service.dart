import 'dart:io';

class ScanService {
  Future<(Set<String>, List<String>, List<String>)> scanDomain(
    String domain,
  ) async {
    final Set<String> allSubdomains = {};
    final List<String> logs = [];
    final List<String> active = [];

    final baseDomain = domain.trim().toLowerCase();

    logs.add('[*] Executando subfinder...');
    final subfinder = await Process.run('subfinder', ['-d', baseDomain]);
    if (subfinder.exitCode == 0) {
      final output =
          (subfinder.stdout as String)
              .split('\n')
              .where((e) => e.trim().isNotEmpty)
              .toSet();
      allSubdomains.addAll(output);
      logs.add('[+] subfinder encontrou ${output.length} subdomínios.');
    } else {
      logs.add('[-] Erro no subfinder: ${subfinder.stderr}');
    }

    logs.add('[*] Executando assetfinder...');
    final assetfinder = await Process.run('assetfinder', [
      '--subs-only',
      baseDomain,
    ]);
    if (assetfinder.exitCode == 0) {
      final output =
          (assetfinder.stdout as String)
              .split('\n')
              .where((e) => e.trim().isNotEmpty)
              .toSet();
      allSubdomains.addAll(output);
      logs.add('[+] assetfinder encontrou ${output.length} subdomínios.');
    } else {
      logs.add('[-] Erro no assetfinder: ${assetfinder.stderr}');
    }

    logs.add('[*] Executando crt.sh...');
    final crtsh = await Process.run('curl', [
      '-s',
      'https://crt.sh/?q=%25.$baseDomain&exclude=expired',
    ]);
    if (crtsh.exitCode == 0) {
      final matches = RegExp(r'<TD>([\w\.\-\*]+)</TD>')
          .allMatches(crtsh.stdout)
          .map((m) => m.group(1)!)
          .where((e) => e.contains(baseDomain));
      final parsed =
          matches
              .expand((e) => e.split('<BR>'))
              .map((e) => e.trim())
              .where((e) => e.isNotEmpty)
              .toSet();
      allSubdomains.addAll(parsed);
      logs.add('[+] crt.sh encontrou ${parsed.length} subdomínios.');
    } else {
      logs.add('[-] Erro no crt.sh');
    }

    logs.add('[*] Executando httprobe para verificar quais estão ativos...');
    try {
      final process = await Process.start('httprobe', [], runInShell: true);
      allSubdomains.forEach((sub) => process.stdin.writeln(sub));
      await process.stdin.close();

      final output =
          await process.stdout.transform(SystemEncoding().decoder).join();
      final activeSet =
          output
              .split('\n')
              .map((line) => line.trim())
              .where((line) => line.isNotEmpty)
              .toSet();
      active.addAll(activeSet);

      logs.add(
        '[+] httprobe identificou ${activeSet.length} subdomínios ativos.',
      );
    } catch (e) {
      logs.add('[-] Erro ao rodar httprobe: $e');
    }

    logs.add(
      '[*] Escaneamento concluído. ${active.length} subdomínios ativos encontrados.',
    );
    return (allSubdomains, logs, active);
  }
}
