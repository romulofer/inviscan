import 'package:flutter/foundation.dart';
import '../services/scan_service.dart';

class ScanViewModel extends ChangeNotifier {
  final ScanService _scanService = ScanService();

  List<String> subdomains = [];
  List<String> activeSubdomains = [];
  List<String> logs = [];
  bool isLoading = false;

  Future<void> scan(String domain) async {
    isLoading = true;
    logs = ['[*] Iniciando escaneamento...'];
    notifyListeners();

    try {
      final (resultSet, resultLogs, active) = await _scanService.scanDomain(
        domain,
      );
      subdomains = resultSet.toList()..sort();
      activeSubdomains = active.toList()..sort();
      logs = resultLogs;
    } catch (e) {
      logs.add('[-] Erro: $e');
    }

    isLoading = false;
    notifyListeners();
  }
}
